package uz.sdmsys.birzum.courier

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {

    private companion object {
        const val S_NOTIF = 0
        const val S_LOC = 1
        const val S_BG = 2
        const val S_BAT = 3
        const val S_FSI = 4
    }

    private lateinit var web: WebView
    private lateinit var offline: View
    private var failed = false
    private val asked = HashSet<Int>()
    private var dialog: AlertDialog? = null

    private val reqNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { nextStep() }
    private val reqLoc = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { nextStep() }
    private val reqBg = registerForActivityResult(ActivityResultContracts.RequestPermission()) { nextStep() }
    private val reqSettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { nextStep() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = findViewById(R.id.web)
        offline = findViewById(R.id.offline)
        findViewById<Button>(R.id.retry).setOnClickListener {
            failed = false
            offline.visibility = View.GONE
            web.loadUrl(BuildConfig.BASE_URL + "c/")
        }
        setupWeb()
        handleIntent(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true)   // ilova yopilmaydi, fonda qoladi
            }
        })

        FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
            if (!t.isNullOrEmpty()) Prefs.setToken(this, t)
        }
        web.loadUrl(BuildConfig.BASE_URL + "c/")
        nextStep()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("from_alarm", false) == true) {
            showOverLockscreen()
            AlarmService.stop(this)
        }
    }

    @Suppress("DEPRECATION")
    private fun showOverLockscreen() {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
    }

    override fun onStart() {
        super.onStart()
        App.visible = true
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
        AlarmService.stop(this)   // ilova ochilgach signal to'xtaydi
        if (Prefs.loggedIn(this)) {
            startTracking()
            val app = applicationContext
            Thread { Push.registerToken(app, force = false) }.start()
        }
    }

    override fun onPause() {
        saveCookie()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onStop() {
        App.visible = false
        super.onStop()
    }

    override fun onDestroy() {
        dialog?.dismiss()
        web.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false   // panel signali (sirena) ovoz chala olishi uchun
        s.setGeolocationEnabled(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.userAgentString = s.userAgentString + " BirZumApp/" + BuildConfig.VERSION_NAME

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        web.addJavascriptInterface(Bridge(), "BzNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (isOurs(request.url)) return false
                openExternal(request.url)   // tel:, xarita, to'lov sahifasi va boshqa tashqi havolalar
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                failed = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                saveCookie()
                if (!failed) offline.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    failed = true
                    offline.visibility = View.VISIBLE
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                callback.invoke(origin, has(Manifest.permission.ACCESS_FINE_LOCATION), false)
            }

            // window.open(...) — masalan, to'lov havolasi: tashqi brauzerda ochiladi
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val temp = WebView(this@MainActivity)
                temp.webViewClient = object : WebViewClient() {
                    private var done = false
                    private fun go(u: Uri) {
                        if (done) return
                        done = true
                        openExternal(u)
                        temp.post { temp.destroy() }
                    }

                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        go(r.url)
                        return true
                    }

                    override fun onPageStarted(v: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                        if (!url.isNullOrEmpty() && url != "about:blank") go(Uri.parse(url))
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    private fun isOurs(u: Uri): Boolean {
        val host = Uri.parse(BuildConfig.BASE_URL).host
        return (u.scheme == "https" || u.scheme == "http") && u.host == host
    }

    private fun openExternal(u: Uri) {
        try {
            val i = if (u.scheme == "tel") Intent(Intent.ACTION_DIAL, u) else Intent(Intent.ACTION_VIEW, u)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            // mos dastur yo'q
        }
    }

    private fun saveCookie() {
        try {
            Prefs.setCookie(this, CookieManager.getInstance().getCookie(BuildConfig.BASE_URL) ?: "")
        } catch (e: Exception) {
        }
    }

    /** Panel (c-1.js) shu obyekt orqali ilovaga xabar beradi: window.BzNative */
    inner class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun appVersion(): String = BuildConfig.VERSION_NAME

        @JavascriptInterface
        fun onLogin() {
            val app = applicationContext
            runOnUiThread {
                Prefs.setLoggedIn(this@MainActivity, true)
                saveCookie()
                startTracking()
            }
            Thread { Push.registerToken(app, force = true) }.start()
        }

        @JavascriptInterface
        fun onLogout() {
            runOnUiThread {
                Prefs.setLoggedIn(this@MainActivity, false)
                stopService(Intent(this@MainActivity, LocationService::class.java))
                AlarmService.stop(this@MainActivity)
            }
        }

        @JavascriptInterface
        fun trackingOn(): Boolean = LocationService.running

        @JavascriptInterface
        fun fixPermissions() {
            runOnUiThread {
                asked.clear()
                nextStep()
            }
        }
    }

    private fun startTracking() {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) return
        try {
            ContextCompat.startForegroundService(this, Intent(this, LocationService::class.java))
        } catch (e: Exception) {
            // tizim hozir ruxsat bermadi: keyingi ochilishda qayta uriniladi
        }
    }

    // ---------------------------------------------------------------- Ruxsatlar (ketma-ket, tushuntirish bilan)

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun nextMissing(): Int? {
        val list = ArrayList<Int>()
        val notifOk = if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.POST_NOTIFICATIONS) else true
        if (!notifOk || !NotificationManagerCompat.from(this).areNotificationsEnabled()) list.add(S_NOTIF)
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) {
            list.add(S_LOC)
        } else if (Build.VERSION.SDK_INT >= 29 && !has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            list.add(S_BG)
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) list.add(S_BAT)
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) list.add(S_FSI)
        return list.firstOrNull { it !in asked }
    }

    private fun nextStep() {
        if (isFinishing || isDestroyed) return
        val step = nextMissing()
        if (step == null) {
            if (Prefs.loggedIn(this)) startTracking()
            return
        }
        asked.add(step)
        val (title, msg) = when (step) {
            S_NOTIF -> R.string.p_notif_t to R.string.p_notif_m
            S_LOC -> R.string.p_loc_t to R.string.p_loc_m
            S_BG -> R.string.p_bg_t to R.string.p_bg_m
            S_BAT -> R.string.p_bat_t to R.string.p_bat_m
            else -> R.string.p_fsi_t to R.string.p_fsi_m
        }
        dialog?.dismiss()
        dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton(R.string.allow) { _, _ -> perform(step) }
            .setNegativeButton(R.string.later) { _, _ -> nextStep() }
            .show()
    }

    private fun appDetails(): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

    private fun perform(step: Int) {
        try {
            when (step) {
                S_NOTIF -> {
                    if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                        reqNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        reqSettings.launch(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        )
                    }
                }
                S_LOC -> reqLoc.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                S_BG -> {
                    if (Build.VERSION.SDK_INT >= 30) reqSettings.launch(appDetails())
                    else reqBg.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                }
                S_BAT -> {
                    try {
                        reqSettings.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    } catch (e: Exception) {
                        reqSettings.launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                }
                else -> {
                    if (Build.VERSION.SDK_INT >= 34) {
                        reqSettings.launch(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                    } else nextStep()
                }
            }
        } catch (e: Exception) {
            nextStep()
        }
    }
}

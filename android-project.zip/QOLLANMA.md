# BirZum Kuryer — Android ilova (WebView + Push + fon joylashuvi)

Ilova `https://birzum.asakaedu.uz/c/` panelini ochadi va quyidagilarni qiladi:
- **Push + baland signal:** yangi buyurtma tayyor bo'lsa, ilova **to'liq yopiq** bo'lsa ham (ekran o'chiq, qulflangan) baland sirena
  takrorlanib chaladi. Ilovani ochsangiz yoki "Ovozsiz" bossangiz to'xtaydi. Buyurtma olinmasa, server push'ni har ~60 soniyada qayta
  yuboradi va signal davom etadi.
- **Fonda joylashuv:** tizimga kirgan kuryerning joylashuvi ilova yopiq bo'lsa ham serverga yuboriladi (doimiy bildirishnoma bilan).
- **Ruxsatlar:** bildirishnoma, joylashuv, fonda joylashuv, batareya cheklovidan chiqarish, ekranni yoqish — ketma-ket tushuntirish bilan so'raydi.

> Eslatma: bu kod mening muhitimda **kompilyatsiya qilib sinalmagan** (Android SDK yo'q). Sintaksis tekshirilgan, lekin birinchi yig'ishda
> kichik xato chiqishi mumkin. Xato chiqsa, GitHub Actions jurnalidagi qizil matnni menga yuboring.

## 1. GitHub'da yig'ish (telefondan)

1. github.com → **New repository** → nomi `birzum-courier`, **Private** (maxfiy) tanlang → Create.
2. **Add file → Create new file** → nom maydoniga aynan `.github/workflows/build.yml` deb yozing (qiyshiq chiziqlar bilan, papka o'zi yaratiladi)
   → `build.yml` faylining matnini ko'chirib qo'ying → **Commit changes**.
3. **Add file → Upload files** → quyidagi **ikkita** faylni yuklang → Commit:
   - `android-project.zip` (shu loyiha arxivi; ochmasdan, o'zi yuklanadi)
   - `google-services.json` (Firebase'dan olgan faylingiz)
4. **Actions** bo'limi → "APK yig'ish" → **Run workflow**. 5–10 daqiqa kuting (yashil belgi chiqadi).
5. Ish tugagach uning ichiga kiring → pastda **Artifacts** → `birzum-kuryer-apk` ni yuklab oling → zip'ni oching → `app-release.apk` ni telefonga o'rnating
   ("noma'lum manbadan o'rnatish" ruxsatini bering).

Paket nomi `google-services.json` dan avtomatik olinadi, shuning uchun Firebase bilan doim mos keladi.
Domen boshqa bo'lsa, `build.yml` yuqoridagi `BASE_URL` qatorini o'zgartiring.

## 2. Imzo kaliti (yangilash uchun kerak)

Kalit bo'lmasa APK sinov kaliti bilan imzolanadi: o'rnatsa bo'ladi, lekin keyingi versiyani **ustidan o'rnatib bo'lmaydi** (avval o'chirish kerak)
va Google Play/RuStore'ga yuklab bo'lmaydi. Bir marta quyidagicha qiling:
1. **Actions → "Imzo kaliti yaratish (bir marta)" → Run workflow** → parol kiriting (eslab qoling).
2. Tugagach **Artifacts → release-keystore** ni yuklab oling → ichidagi `release.jks.b64` faylni oching, matnini nusxalang.
3. Repozitoriy **Settings → Secrets and variables → Actions → New repository secret**:
   - `KEYSTORE_BASE64` = nusxalangan matn
   - `KEYSTORE_PASSWORD` = kiritgan parolingiz
4. `release.jks` faylini **xavfsiz joyda saqlang** (yo'qotsangiz, ilovani yangilab bo'lmaydi).

## 3. Birinchi ishga tushirish va tekshirish

1. Ilovani oching, ruxsat oynalarining **hammasiga** "Ruxsat berish" bosing (batareya va "Doim ruxsat" muhim).
2. Login, parol va PIN bilan kiring (kuryerga admin: Kuryerlar → 🔑 beradi).
3. Admin panel → **Kuryerlar**: kuryer qatorida **📱** belgisi chiqishi kerak (ilova tokeni serverga yetib kelgan).
4. Shu qatordagi **🔔** tugmasini bosing: telefonda signal chalinishi kerak. Ilovani yopib (chiqib) qayta sinab ko'ring.
5. Haqiqiy buyurtma: do'kon "Tayyor" bosganda signal chalinadi.

## Push kelmasa

- **📱 belgisi yo'q:** ilova token yubora olmagan. Ilovaga qayta kiring (login). Internetni tekshiring.
- **🔔 bosganda xato:** admin panel xabarida Firebase javobi chiqadi:
  - `UNREGISTERED` / `NOT_FOUND` — token eskirgan: ilovaga qayta kiring.
  - `SENDER_ID_MISMATCH` / `403` — `google-services.json` boshqa Firebase loyihasidan, serverdagi xizmat akkaunti (service account) esa boshqasidan. Ikkalasi **bir loyihadan** bo'lishi kerak.
  - `401` / `invalid_grant` — serverdagi xizmat akkaunti fayli yo'li yoki ruxsati noto'g'ri.
- **Xato yo'q, lekin telefonda signal yo'q:**
  - Telefon sozlamalari → Ilovalar → BirZum Kuryer → **Batareya → «Cheklovsiz»**.
  - Xiaomi/Redmi: Xavfsizlik → Ilovalar → **Avtostart** yoqing, "Batareya tejash: Cheklovsiz".
  - Samsung: Batareya → "Uxlayotgan ilovalar"dan olib tashlang.
  - Ilovani **«Majburan to'xtatish» (Force stop)** qilmang: shundan keyin Android push'ni umuman yetkazmaydi, ilova qayta ochilmaguncha.
  - Telefonda Google Play Services bo'lishi shart.
  - Bildirishnomalar: "Yangi buyurtma (ovozli)" kanali o'chirilmagan bo'lsin, "Bezovta qilmang" rejimi o'chiq bo'lsin.

## Sessiya

Server qoidasi: kuryer kuniga bir marta kiradi (24 soat) va 4 soat paneldan foydalanmasa, sessiya tugaydi. Fon joylashuvi va push
tokeni yuborish bu hisobni **yangilamaydi**. Sessiya tugasa, joylashuv xizmati to'xtaydi va "Sessiya tugadi" bildirishnomasi chiqadi.
